









Inspire_hackathon_df <- lapply(c("synthetic_hdss_v3", "synthetic_facility_v3"), function(synthetic)
  read_csv(paste0(synthetic, ".csv")))

str(Inspire_hackathon_df)





